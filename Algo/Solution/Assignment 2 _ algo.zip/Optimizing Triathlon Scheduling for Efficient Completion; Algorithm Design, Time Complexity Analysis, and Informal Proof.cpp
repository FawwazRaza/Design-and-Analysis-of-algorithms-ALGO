///*Suppose you want to organize activities for some campers. This includes a triathalon exercise: each
//contestant must swim 20 laps of a pool, then bike 10 miles, then run 3 miles. The contestants must use the
//pool one at a time. In other words, first one contestant swims the 20 laps, gets out, and starts biking. As
//soon as this first person is out of the pool, a second contestant begins swimming the 20 laps; as soon as he
//or she is out and starts biking, a third contestant begins swimming . . . and so on. Each contestant has a
//projected swimming time (the expected time it will take him or her to complete the 20 laps), a projected
//biking time (the expected time it will take him or her to complete the 10 miles of bicycling), and a projected
//running time (the time it will take him or her to complete the 3 miles of running). You want to decide on a
//schedule for the triathalon: an order in which to sequence the starts of the contestants. The completion time
//of a schedule is the earliest time at which all contestants will be finished with all three legs of the triathalon,
//assuming they each spend exactly their projected swimming, biking, and running times on the three parts.
//(Again, note that participants can bike and run simultaneously, but at most one person can be in the pool at
//any time.) What�s the best order for sending people out, if one wants the whole competition to be over as
//early as possible?
//a. Design an efficient algorithm for finding such a schedule.
//b. Analyze the running time of your algorithm as a function of n, the number of contestants.
//c. Prove that your algorithm works (Give informal argument).*/
//
//#include <iostream>
//#include <vector>
//#include <algorithm>
//using namespace std;
//
//void csort(vector<pair<int, pair<int, int>>>& arr) 
//{
//    int maxe = INT_MIN;
//    for (int i = 0; i < arr.size(); i++) 
//    {
//        maxe = max(maxe, arr[i].first);
//    }
//
//    vector<int> count(maxe + 1, 0);
//
//    for (int i = 0; i < arr.size(); i++) 
//    {
//        count[arr[i].first]++;
//    }
//
//    for (int i = 1; i < count.size(); i++) 
//    {
//        count[i] += count[i - 1];
//    }
//
//    vector<pair<int, pair<int, int>>> output(arr.size());
//
//    for (int i = arr.size() - 1; i >= 0; i--) 
//    {
//        output[count[arr[i].first] - 1] = arr[i];
//        count[arr[i].first]--;
//    }
//
//    for (int i = 0; i < arr.size(); i++) 
//    {
//        arr[i] = output[i];
//    }
//}
//
//int main() {
//    vector<pair<int, pair<int, int>>> race;
//    race.push_back({ 3, {10, 3} });
//    race.push_back({ 2, {10, 3} });
//    race.push_back({ 4, {10, 3} });
//
//    cout << "input :" << endl;
//    for (int i = 0; i < race.size(); i++) 
//    {
//        cout << "    [ " << race[i].first << " | " << race[i].second.first << " | " << race[i].second.second << " ]        ";
//    }
//    cout << endl;
//
//    csort(race);
//
//    cout << "sorted race based on the swimming:" << endl;
//    for (int i = 0; i < race.size(); i++) 
//    {
//        cout << "    [ " << race[i].first << " | " << race[i].second.first << " | " << race[i].second.second << " ]        ";
//    }
//    cout << endl;
//
//    return 0;
//}
