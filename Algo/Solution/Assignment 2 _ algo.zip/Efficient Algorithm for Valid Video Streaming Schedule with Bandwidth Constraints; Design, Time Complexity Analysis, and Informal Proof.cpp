///*The spread of COVID-19 in Pakistan resulted in closure of academic Institutes and started a new era of
//online classes. Whenever there is some extraordinary situation (general election in the country, heavy
//rainfall etc), the management of FAST move the classes to online mode. The management of FAST Lahore
//decided to share online sessions (video lectures) with the students of online classes. There are total n videos
//that need to be streamed one after the other. Each video vi consists of bi bits that needs to be sent at a
//constant rate over a period of ti seconds. There is only one connection allowed so two videos can�t be sent
//at a time. This means scheduling of videos is required. Whichever order is chosen, there cannot be any
//delays between the end of one video and the start of the next. The connection does not want its user taking
//up too much bandwidth, so it imposes the following constraint, using a fixed parameter r: For each natural
//number t > 0, the total number of bits you send over the time interval from 0 to t cannot exceed r*t. A
//schedule is considered valid if it satisfies the constraint imposed by the connection. You are a computer
//science expert and management of FAST need your services. Given a set of n video streams specified by
//its number of bits bi and its time duration ti, they need to determine whether there exists a valid schedule
//that satisfies connection parameter r. For example you have 3 videos with (b1,t1)=(2000,1), (b2,t2)=(6000,2)
//and (b3,t3)=(2000,1) also r=5000. The schedule that runs videos in order 1, 2, 3, is valid because at time t=1
//the first stream is sent and 2000 < 5000*1 at time t=2 2000+3000(half of second video)<5000*2 similar
//calculation can be done to check the constraint for t=3 and t=4.
//a. Design an efficient algorithm that takes a set of n streams each specified by bi and ti along with r
//and determines whether a valid schedule exists or not.
//b. Analyze the running time of your algorithm as a function of n.
//c. Prove that your algorithm works (Give informal argument).*/
//
//#include <iostream>
//#include <vector>
//#include <cstdlib> // Include for rand() and srand()
//#include <ctime>   // Include for time()
//#include <algorithm>
//using namespace std;
//
//void countingSort(vector<pair<int, int>>& arr) {
//    int maxTime = INT_MIN;
//    for (int i = 0; i < arr.size(); i++) {
//        maxTime = max(maxTime, arr[i].second);
//    }
//
//    vector<int> count(maxTime + 1, 0);
//
//    for (int i = 0; i < arr.size(); i++) {
//        count[arr[i].second]++;
//    }
//
//    for (int i = 1; i < count.size(); i++) {
//        count[i] += count[i - 1];
//    }
//
//    vector<pair<int, int>> output(arr.size());
//
//    for (int i = arr.size() - 1; i >= 0; i--) {
//        output[count[arr[i].second] - 1] = arr[i];
//        count[arr[i].second]--;
//    }
//
//    for (int i = 0; i < arr.size(); i++) {
//        arr[i] = output[i];
//    }
//}
//
//int main() {
//    int n;
//    cout << "Enter the number of videos: ";
//    cin >> n;
//
//    srand(time(0)); 
//
//    vector<pair<int, int>> videos;
//    int bi, ti;
//    int r = 5000;
//    cout << "Enter videos in the format (bi, ti):" << endl;
//    for (int i = 0; i < n; i++) {
//        //cin >> bi >> ti;
//        bi = rand() % 10000;
//        ti = rand() % 10+1;
//        videos.push_back(make_pair(bi, ti));
//    }
//
//    countingSort(videos);
//
//    cout << "Sorted videos based on time duration (ti):" << endl;
//    for (int i = 0; i < videos.size(); i++) {
//        cout << "(" << videos[i].first << ", " << videos[i].second << ") ";
//    }
//    cout << endl;
//    //int arr[100] = { 0 };
//    //int arr1[100] = { 0 };
//    //int tempnum = 0;
//    //int tempnum1 = 0;
//    //for (int i = 0; i < n; i++)
//    //{
//    //    for (int j = 0; j < n; j++)
//    //    {
//    //        tempnum *= 10;
//    //        tempnum1 = rand() % n + 1;
//    //        arr1[j-1] = tempnum1;
//    //        if (tempnum1)
//    //        {
//    //        }
//    //        tempnum+=tempnum1;
//    //    }
//    //    cout << endl;
//    //    arr[i] = tempnum;
//    //    tempnum = 0;
//    //}
//    //for (int i = 0; i < n; i++)
//    //{
//    //    cout << arr[i] << "  |  ";
//    //}
//    //cout << endl;
//    int patt[100] = { 0 };
//    int patt1[100] = { 0 };
//    int patt2[100] = { 0 };
//    cout << "please write the pattern : ";
//    for (int i = 0; i < n; i++)
//    {
//        cin >> patt[i];
//    }
//    for (int i = 0; i < n; i++)
//    {
//        patt1[i] += videos[i].first;
//        if(patt1[i]>= (r * videos[i].second))
//        {
//            cout << "pattern isn't correct ::teminating ";
//            break;
//        }
//    }
//    cout << "pattern is correct ::teminating ";
//    return 0;
//}
//
