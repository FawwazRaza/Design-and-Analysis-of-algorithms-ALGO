﻿///*Suppose that in Problem 6  (You are planning to start a new business of printing flexes. In the first step you have bought a printing
//machine. Every day you receive printing orders from n different customers. Customer Ci’s job requires time
//ti. The wait time of a customer Ci is wi which is the amount of time the customer waited till its job
//completion. You have only one printing machine so you have to devise a schedule of printing. You want
//your customers to be happy. The happiness of the customer is dependent on the wait time. The smaller the
//wait time the happier your customer is. Devise a schedule that minimizes the total wait time of all the n
//customers. Suppose there are three customer with job time t1=4, t2=5, t3=2. If you schedule (1, 2, 3) then
//w1=4, w2=9, w3=11 total wait time is 4+9+11=24
//a. Design an algorithm for finding such a schedule i.e given ti for every customer, find a schedule
//that minimizes∑ wi
//n
//i=1
//.
//
//b. Analyze the running time of your algorithm as a function of n.
//c. Prove that your algorithm works (Give informal argument).), you have prioritize your customers i.e. each customer Ci also has a priority pi
//that represents his/her importance. So now you want to find a schedule that minimizes the weighted sum of
//waiting time based on customer priority. Specifically you want to minimize ∑ wipi
//n
//i=1
//
//a. Design an algorithm for finding such a schedule i.e. given ti and pi for every customer, find a
//schedule that minimize ∑ wipi
//n
//i=1
//
//b. Analyze the running time of your algorithm as a function of n.
//c. Prove that your algorithm works (Give informal argument).*/
//
//
//#include <iostream>
//#include <vector>
//using namespace std;
//
//void csort(vector<int>& arr) {
//    int max = *max_element(arr.begin(), arr.end());
//    vector<int> count(max + 1, 0);
//
//    for (int i = 0; i < arr.size(); i++) {
//        count[arr[i]]++;
//    }
//
//    for (int i = 1; i < count.size(); i++) {
//        count[i] += count[i - 1];
//    }
//
//    vector<int> temp(arr.size());
//
//
//    for (int i = arr.size() - 1; i >= 0; i--) {
//        temp[count[arr[i]] - 1] = arr[i];
//        count[arr[i]]--;
//    }
//
//
//    for (int i = 0; i < arr.size(); i++) {
//        arr[i] = temp[i];
//    }
//}
//
//int main() {
//    vector<int> arr = { 1,5,1,54,12,3};
//    vector<int> priority= { 5, 6, 5, 43, 13, 17 };
//    if (arr.size() != priority.size())
//    {
//        
//        cout << "wrong input :: terminating" << endl;
//        return 0;
//    }
//    vector<int> temp;
//    int t;
//    for (int i = 0; i < arr.size(); i++)
//    {
//
//        t= arr[i] * priority[i];
//        temp.push_back(t);
//    }
//    
//    csort(temp);
//
//    cout << " array after sorting for min waiting: ";
//    for (int i = 0; i < temp.size(); i++) {
//        cout << temp[i] << " ";
//    }
//    cout << endl;
//    int sum = 0;
//    cout << " waiting time is per person: ";
//    for (int i = 0; i < temp.size(); i++) {
//        sum += temp[i];
//        cout << sum << " ";
//    }
//    cout << endl;
//    cout << "total waiting time is : " << sum;
//    return 0;
//}
