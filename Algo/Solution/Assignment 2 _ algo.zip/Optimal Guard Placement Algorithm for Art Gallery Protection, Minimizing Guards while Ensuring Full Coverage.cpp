///*Suppose there is an art gallery in form of a straight long hall. You are given an ordered set P= {p1, p2, ...,
//pn}of real numbers that represent the positions of precious paintings or sculptures in this hallway. A guard
//can protect all the objects that comes within d distance on his left and right.
//d. Design an algorithm for finding a placements of guards that uses the minimum number of guards
//to guard all the objects with positions in P.
//e. Analyze the running time of your algorithm as a function of n, the number of objects that need
//guarding.
//f. Prove that your algorithm works (Give informal argument).*/
//#include <iostream>
//#include <vector>
//#include <algorithm>
//#include <cmath>
//using namespace std;
//
//void csort(vector<int>& arr) {
//    int max = *max_element(arr.begin(), arr.end());
//    vector<int> count(max + 1, 0);
//
//    for (int i = 0; i < arr.size(); i++) {
//        count[arr[i]]++;
//    }
//
//    for (int i = 1; i < count.size(); i++) {
//        count[i] += count[i - 1];
//    }
//
//    vector<int> temp(arr.size());
//
//    for (int i = arr.size() - 1; i >= 0; i--) {
//        temp[count[arr[i]] - 1] = arr[i];
//        count[arr[i]]--;
//    }
//
//    for (int i = 0; i < arr.size(); i++) {
//        arr[i] = temp[i];
//    }
//}
//
//int main() {
//    int n=0;
//    srand(time(0));
//    while (n != -1) {
//        cout << "Enter the number of elements: ";
//        cin >> n;
//
//        vector<int> arr(n);
//
//        for (int i = 0; i < n; i++) {
//            arr[i] = i + 1;
//        }
//
//        cout << "Enter the distance d: ";
//        int d;
//        cin >> d;
//
//        csort(arr);
//
//        cout << "Array after sorting: ";
//        for (int i = 0; i < arr.size(); i++) {
//            cout << arr[i] << " ";
//        }
//        cout << endl;
//
//        float temp = d * 2 + 1;
//        float temp2 = ceil(temp / n);
//        int pos = d + 1;
//        int j = 0;
//
//        cout << "Positions of guards:\n";
//        for (int i = 0; i < n; i += ((d * 2) + 1)) {
//            if (i >= n - 1)
//            {
//                pos -= d;
//                //break;
//            }
//            cout << "Guard " << j + 1 << ": " << pos << endl;
//            pos += ((d * 2) + 1);
//            j++;
//        }
//    }
//    return 0;
//}
////1 2 6 =>10
