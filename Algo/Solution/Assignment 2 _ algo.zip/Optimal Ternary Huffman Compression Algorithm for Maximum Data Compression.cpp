///*Ternary Huffman. Trimedia Disks Inc. has developed ternary hard disks. Each cell on a disk can now store
//values 0, 1, or 2 (instead of just 0 or 1). To take advantage of this new technology, we need a modified
//Huffman algorithm for compressing sequences of characters from an alphabet of size n, where the characters
//
//occur with known frequencies f1, f2, ..., fn. Your algorithm should encode each character with a variable-
//length code word over the values 0, 1, 2 such that no code word is a prefix of another code word and so as
//
//to obtain the maximum possible compression.
//a. Design an algorithm for finding optimal code.
//b. Analyze the running time of your algorithm as a function of n, the number of unique characters.
//c. Prove that your algorithm works (Give informal argument).*/
//#include <iostream>
//#include <queue>
//#include <unordered_map>
//#include <string>
//using namespace std;
//
//class Node 
//{
//public:
//    char data;
//    int freq;
//    Node* left;
//    Node* right;
//    Node* middle;
//
//    Node(char data, int freq) : data(data), freq(freq), left(nullptr), right(nullptr), middle(nullptr) {}
//
//    bool isleaf() const 
//    {
//        return left == nullptr && right == nullptr && middle == nullptr;
//    }
//};
//
//class cmpnode 
//{
//public:
//    bool operator()(const Node* a, const Node* b) const 
//    {
//        return a->freq > b->freq;
//    }
//};
//
//Node* make(const unordered_map<char, int>& chfreq) 
//{
//    priority_queue<Node*, vector<Node*>, cmpnode> pq;
//
//    for (const auto& pair : chfreq) 
//    {
//        pq.push(new Node(pair.first, pair.second));
//    }
//
//    while (pq.size() > 1)
//    {
//        Node* left = pq.top();
//        pq.pop();
//        Node* middle = pq.top();
//        pq.pop();
//        Node* right = pq.top();
//        pq.pop();
//
//        Node* internalnode = new Node('\0', left->freq + middle->freq + right->freq);
//        internalnode->left = left;
//        internalnode->middle = middle;
//        internalnode->right = right;
//
//        pq.push(internalnode);
//    }
//
//    return pq.top();
//}
//
//void givecode(Node* root, unordered_map<char, string>& codword, string code = "") 
//{
//    if (root) 
//    {
//        if (root->isleaf())
//        {
//            codword[root->data] = code;
//        }
//        givecode(root->left, codword, code + '0');
//        givecode(root->middle, codword, code + '1');
//        givecode(root->right, codword, code + '2');
//    }
//}
//
//int main() {
//    unordered_map<char, int> chfreq = 
//    {
//        {'a', 15}, {'b', 91}, {'c', 12}, {'d', 13}, {'e', 6}, {'f', 23}, {'g', 55}
//    };
//
//    Node* root = make(chfreq);
//
//    unordered_map<char, string> codword;
//    givecode(root, codword);
//
//    cout << "huffman after encrypt:\n";
//    unordered_map<char, string>::const_iterator it;
//    for (it = codword.begin(); it != codword.end(); ++it) 
//    {
//        cout << it->first << ": " << it->second << "\n";
//    }
//
//
//    return 0;
//}
